package com.example.app

import android.media.Image

class ContactArray(name: String) {
    var name: String = name
//    var img : Int = img
        private set
}
