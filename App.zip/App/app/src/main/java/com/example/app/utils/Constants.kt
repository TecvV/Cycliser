package com.example.app.utils

object Constants{
    const val USERS: String = "users"

    const val IMAGE : String = "image"
    const val NAME : String = "name"
    const val MOBILE : String = "mobile"
}